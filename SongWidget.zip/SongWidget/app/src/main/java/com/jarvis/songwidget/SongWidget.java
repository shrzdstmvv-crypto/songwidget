package com.jarvis.songwidget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.widget.RemoteViews;

import java.io.File;

public class SongWidget extends AppWidgetProvider {
    static final String ACTION_TOGGLE = "com.jarvis.songwidget.TOGGLE";
    static final String PREFS = "song";

    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        for (int id : ids) m.updateAppWidget(id, build(c));
    }

    @Override
    public void onReceive(Context c, Intent i) {
        super.onReceive(c, i);
        if (ACTION_TOGGLE.equals(i.getAction())) {
            c.startForegroundService(new Intent(c, MusicService.class));
        }
    }

    static RemoteViews build(Context c) {
        SharedPreferences sp = c.getSharedPreferences(PREFS, 0);
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget);
        v.setTextViewText(R.id.title, sp.getString("title", c.getString(R.string.default_title)));
        v.setTextViewText(R.id.artist, sp.getString("artist", c.getString(R.string.default_artist)));
        v.setImageViewBitmap(R.id.cover, coverBitmap(c));

        Intent i = new Intent(c, SongWidget.class).setAction(ACTION_TOGGLE);
        PendingIntent pi = PendingIntent.getBroadcast(c, 0, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        v.setOnClickPendingIntent(R.id.root, pi);
        v.setOnClickPendingIntent(R.id.cover, pi);
        v.setOnClickPendingIntent(R.id.texts, pi);
        v.setOnClickPendingIntent(R.id.title, pi);
        v.setOnClickPendingIntent(R.id.artist, pi);
        return v;
    }

    /** Yumaloq burchakli, ingichka oq chiziqli kvadrat; ichida rasm (bo'lsa). */
    static Bitmap coverBitmap(Context c) {
        final int S = 192;
        final float stroke = 3f, r = 36f;
        Bitmap out = Bitmap.createBitmap(S, S, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(out);
        RectF rect = new RectF(stroke, stroke, S - stroke, S - stroke);

        File f = new File(c.getFilesDir(), "cover.jpg");
        Bitmap src = f.exists() ? BitmapFactory.decodeFile(f.getPath()) : null;
        if (src != null) {
            Path clip = new Path();
            clip.addRoundRect(rect, r, r, Path.Direction.CW);
            cv.save();
            cv.clipPath(clip);
            cv.drawBitmap(src, null, new RectF(0, 0, S, S), new Paint(Paint.FILTER_BITMAP_FLAG));
            cv.restore();
            src.recycle();
        }

        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(stroke);
        p.setColor(Color.WHITE);
        cv.drawRoundRect(rect, r, r, p);

        if (src == null) {
            Paint t = new Paint(Paint.ANTI_ALIAS_FLAG);
            t.setColor(Color.WHITE);
            t.setTextSize(100f);
            t.setTextAlign(Paint.Align.CENTER);
            cv.drawText("\u266A", S / 2f, S / 2f + 34f, t);
        }
        return out;
    }

    static void refresh(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        int[] ids = m.getAppWidgetIds(new ComponentName(c, SongWidget.class));
        for (int id : ids) m.updateAppWidget(id, build(c));
    }
}
