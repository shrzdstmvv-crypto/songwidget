package com.jarvis.songwidget;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.drawable.GradientDrawable;
import android.media.ExifInterface;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.text.InputType;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {
    private static final int REQ_SONG = 1, REQ_COVER = 2;
    private SharedPreferences sp;
    private EditText etTitle, etArtist;
    private TextView tvSong, tvCover;
    private ImageView bgView;
    private LinearLayout root;
    private float dp;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences(SongWidget.PREFS, 0);
        dp = getResources().getDisplayMetrics().density;

        FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(Color.BLACK);

        bgView = new ImageView(this);
        bgView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        frame.addView(bgView, new FrameLayout.LayoutParams(-1, -1));

        View scrim = new View(this);
        scrim.setBackgroundColor(0xB3000000);
        frame.addView(scrim, new FrameLayout.LayoutParams(-1, -1));

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (20 * dp);
        root.setPadding(pad, (int) (36 * dp), pad, pad);

        TextView title = text("Музыкальный виджет", 24, Color.WHITE);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        add(title, 0);

        add(text("Удерживайте палец на главном экране → Виджеты → «Музыкальный виджет». "
                + "Нажмите на виджет — музыка играет, нажмите ещё раз — пауза.", 14, 0xCCFFFFFF), 8);

        add(button("Выбрать песню", v -> pick("audio/*", REQ_SONG)), 20);
        tvSong = text("", 13, 0xCCFFFFFF);
        add(tvSong, 4);

        add(button("Выбрать картинку", v -> pick("image/*", REQ_COVER)), 16);
        add(button("Авто: картинка из песни", v -> autoCover()), 8);
        tvCover = text("", 13, 0xCCFFFFFF);
        add(tvCover, 4);

        etTitle = edit("Название песни", sp.getString("title", ""));
        add(etTitle, 16);
        etArtist = edit("Исполнитель", sp.getString("artist", ""));
        add(etArtist, 8);

        add(button("Авто: название и исполнитель из песни", v -> autoText()), 12);
        add(button("Сохранить", v -> {
            saveTexts();
            Toast.makeText(this, "Сохранено", Toast.LENGTH_SHORT).show();
        }), 8);

        ScrollView sv = new ScrollView(this);
        sv.addView(root, new ViewGroup.LayoutParams(-1, -2));
        frame.addView(sv, new FrameLayout.LayoutParams(-1, -1));
        setContentView(frame);

        loadBg();
        updateStatus();
    }

    // ---------- UI helpers ----------
    private TextView text(String s, int sp, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }

    private Button button(String s, View.OnClickListener l) {
        Button bt = new Button(this);
        bt.setText(s);
        bt.setTextColor(Color.WHITE);
        bt.setAllCaps(false);
        GradientDrawable g = new GradientDrawable();
        g.setColor(0x33FFFFFF);
        g.setStroke((int) dp, 0x99FFFFFF);
        g.setCornerRadius(14 * dp);
        bt.setBackground(g);
        bt.setOnClickListener(l);
        return bt;
    }

    private EditText edit(String hint, String value) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(0x88FFFFFF);
        e.setTextColor(Color.WHITE);
        e.setInputType(InputType.TYPE_CLASS_TEXT);
        e.setSingleLine(true);
        e.setText(value);
        return e;
    }

    private void add(View v, int topDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = (int) (topDp * dp);
        root.addView(v, lp);
    }

    private void loadBg() {
        File f = new File(getFilesDir(), "cover_bg.jpg");
        Bitmap bm = f.exists() ? BitmapFactory.decodeFile(f.getPath()) : null;
        bgView.setImageBitmap(bm);
    }

    private void updateStatus() {
        tvSong.setText(new File(getFilesDir(), "song").exists()
                ? "Песня: загружена ✓" : "Песня: не выбрана");
        tvCover.setText(new File(getFilesDir(), "cover.jpg").exists()
                ? "Картинка: загружена ✓" : "Картинка: не выбрана");
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }

    // ---------- title / artist ----------
    private void saveTexts() {
        String t = etTitle.getText().toString().trim();
        String a = etArtist.getText().toString().trim();
        SharedPreferences.Editor e = sp.edit();
        if (t.isEmpty()) e.remove("title"); else e.putString("title", t);
        if (a.isEmpty()) e.remove("artist"); else e.putString("artist", a);
        e.apply();
        SongWidget.refresh(this);
    }

    @Override
    protected void onPause() {
        saveTexts();
        super.onPause();
    }

    private void autoText() {
        File song = new File(getFilesDir(), "song");
        if (!song.exists()) { toast("Сначала выберите песню"); return; }
        String t = null, a = null;
        try {
            MediaMetadataRetriever r = new MediaMetadataRetriever();
            r.setDataSource(song.getPath());
            t = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE);
            a = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST);
            if (a == null || a.trim().isEmpty())
                a = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUMARTIST);
            r.release();
        } catch (Exception ignored) { }
        if (t == null || t.trim().isEmpty()) t = sp.getString("fname", null);
        boolean any = false;
        if (t != null && !t.trim().isEmpty()) { etTitle.setText(t.trim()); any = true; }
        if (a != null && !a.trim().isEmpty()) { etArtist.setText(a.trim()); any = true; }
        if (any) { saveTexts(); toast("Заполнено из файла песни"); }
        else toast("В файле песни нет названия и исполнителя");
    }

    // ---------- picking ----------
    private void pick(String type, int req) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(type);
        startActivityForResult(i, req);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        final Uri uri = data.getData();
        new Thread(() -> {
            boolean ok = true;
            try {
                if (req == REQ_SONG) copySong(uri); else saveCover(uri);
            } catch (Exception e) { ok = false; }
            final boolean fOk = ok;
            runOnUiThread(() -> {
                if (!fOk) toast("Не удалось загрузить файл");
                loadBg();
                updateStatus();
                SongWidget.refresh(this);
            });
        }).start();
    }

    private void copySong(Uri uri) throws Exception {
        File tmp = new File(getFilesDir(), "song.tmp");
        try (InputStream in = getContentResolver().openInputStream(uri);
             OutputStream out = new FileOutputStream(tmp)) {
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        }
        File dst = new File(getFilesDir(), "song");
        if (dst.exists()) dst.delete();
        if (!tmp.renameTo(dst)) throw new Exception("rename");

        String name = null;
        try (Cursor c = getContentResolver().query(uri,
                new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) name = c.getString(0);
        } catch (Exception ignored) { }
        if (name != null) {
            int dot = name.lastIndexOf('.');
            if (dot > 0) name = name.substring(0, dot);
        }
        sp.edit().putInt("pos", 0).putString("fname", name).apply();
        stopService(new Intent(this, MusicService.class));
    }

    // ---------- cover ----------
    private void autoCover() {
        File song = new File(getFilesDir(), "song");
        if (!song.exists()) { toast("Сначала выберите песню"); return; }
        new Thread(() -> {
            String msg = null;
            try {
                MediaMetadataRetriever r = new MediaMetadataRetriever();
                r.setDataSource(song.getPath());
                byte[] pic = r.getEmbeddedPicture();
                r.release();
                if (pic == null) {
                    msg = "В файле песни нет картинки";
                } else {
                    BitmapFactory.Options o = new BitmapFactory.Options();
                    o.inJustDecodeBounds = true;
                    BitmapFactory.decodeByteArray(pic, 0, pic.length, o);
                    o.inSampleSize = sampleFor(o.outWidth, o.outHeight);
                    o.inJustDecodeBounds = false;
                    Bitmap bm = BitmapFactory.decodeByteArray(pic, 0, pic.length, o);
                    if (bm == null) msg = "Не удалось прочитать картинку из песни";
                    else processCover(bm);
                }
            } catch (Exception e) { msg = "Не удалось достать картинку из песни"; }
            final String fMsg = msg;
            runOnUiThread(() -> {
                if (fMsg != null) toast(fMsg);
                loadBg();
                updateStatus();
                SongWidget.refresh(this);
            });
        }).start();
    }

    private int sampleFor(int w, int h) {
        int sample = 1, min = Math.min(w, h);
        while (min / (sample * 2) >= 720) sample *= 2;
        return sample;
    }

    private void saveCover(Uri uri) throws Exception {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            BitmapFactory.decodeStream(in, null, o);
        }
        o.inSampleSize = sampleFor(o.outWidth, o.outHeight);
        o.inJustDecodeBounds = false;
        Bitmap bmp;
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            bmp = BitmapFactory.decodeStream(in, null, o);
        }
        if (bmp == null) throw new Exception("decode");

        int rot = 0;
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            int ori = new ExifInterface(in).getAttributeInt(
                    ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
            if (ori == ExifInterface.ORIENTATION_ROTATE_90) rot = 90;
            else if (ori == ExifInterface.ORIENTATION_ROTATE_180) rot = 180;
            else if (ori == ExifInterface.ORIENTATION_ROTATE_270) rot = 270;
        } catch (Exception ignored) { }
        if (rot != 0) {
            Matrix m = new Matrix();
            m.postRotate(rot);
            bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.getWidth(), bmp.getHeight(), m, true);
        }
        processCover(bmp);
    }

    /** Bitta rasmdan ikkita fayl: vidjet uchun 192x192 kvadrat va ilova foni uchun katta nusxa. */
    private void processCover(Bitmap bmp) throws Exception {
        int w = bmp.getWidth(), h = bmp.getHeight(), min = Math.min(w, h);

        Bitmap bg = bmp;
        if (min > 720) {
            float s = 720f / min;
            bg = Bitmap.createScaledBitmap(bmp, Math.round(w * s), Math.round(h * s), true);
        }
        try (OutputStream out = new FileOutputStream(new File(getFilesDir(), "cover_bg.jpg"))) {
            bg.compress(Bitmap.CompressFormat.JPEG, 85, out);
        }

        Bitmap sq = Bitmap.createBitmap(bmp, (w - min) / 2, (h - min) / 2, min, min);
        Bitmap small = Bitmap.createScaledBitmap(sq, 192, 192, true);
        try (OutputStream out = new FileOutputStream(new File(getFilesDir(), "cover.jpg"))) {
            small.compress(Bitmap.CompressFormat.JPEG, 90, out);
        }
    }
}
