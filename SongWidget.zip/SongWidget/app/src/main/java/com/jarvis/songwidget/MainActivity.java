package com.jarvis.songwidget;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {
    private static final int REQ_SONG = 1, REQ_COVER = 2;
    private SharedPreferences sp;
    private EditText etTitle, etArtist;
    private TextView tvSong, tvCover;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences(SongWidget.PREFS, 0);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (20 * getResources().getDisplayMetrics().density);
        root.setPadding(pad, pad, pad, pad);

        TextView hint = new TextView(this);
        hint.setText("Bosh ekranni uzoq bosing \u2192 Vidjetlar \u2192 \u00abQo\u2018shiq vidjeti\u00bb.\n"
                + "Vidjetni bossangiz qo\u2018shiq boshlanadi, yana bossangiz to\u2018xtaydi.");
        hint.setTextSize(15);
        root.addView(hint);

        Button bSong = new Button(this);
        bSong.setText("Qo\u2018shiq tanlash");
        bSong.setOnClickListener(v -> pick("audio/*", REQ_SONG));
        root.addView(bSong);
        tvSong = new TextView(this);
        root.addView(tvSong);

        Button bCover = new Button(this);
        bCover.setText("Rasm tanlash");
        bCover.setOnClickListener(v -> pick("image/*", REQ_COVER));
        root.addView(bCover);
        tvCover = new TextView(this);
        root.addView(tvCover);

        etTitle = new EditText(this);
        etTitle.setHint("Qo\u2018shiq nomi");
        etTitle.setInputType(InputType.TYPE_CLASS_TEXT);
        etTitle.setText(sp.getString("title", ""));
        root.addView(etTitle);

        etArtist = new EditText(this);
        etArtist.setHint("Muallif");
        etArtist.setInputType(InputType.TYPE_CLASS_TEXT);
        etArtist.setText(sp.getString("artist", ""));
        root.addView(etArtist);

        Button bSave = new Button(this);
        bSave.setText("Saqlash");
        bSave.setOnClickListener(v -> {
            saveTexts();
            Toast.makeText(this, "Saqlandi", Toast.LENGTH_SHORT).show();
        });
        root.addView(bSave);

        ScrollView sv = new ScrollView(this);
        sv.addView(root, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(sv);
        updateStatus();
    }

    private void updateStatus() {
        tvSong.setText(new File(getFilesDir(), "song").exists() ? "Qo\u2018shiq: yuklangan \u2713" : "Qo\u2018shiq: yo\u2018q");
        tvCover.setText(new File(getFilesDir(), "cover.jpg").exists() ? "Rasm: yuklangan \u2713" : "Rasm: yo\u2018q");
    }

    private void saveTexts() {
        String t = etTitle.getText().toString().trim();
        String a = etArtist.getText().toString().trim();
        SharedPreferences.Editor e = sp.edit();
        if (t.isEmpty()) e.remove("title"); else e.putString("title", t);
        if (a.isEmpty()) e.remove("artist"); else e.putString("artist", a);
        e.apply();
        SongWidget.refresh(this);
    }

    @Override
    protected void onPause() {
        saveTexts();
        super.onPause();
    }

    private void pick(String type, int req) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(type);
        startActivityForResult(i, req);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        final Uri uri = data.getData();
        new Thread(() -> {
            boolean ok;
            try {
                if (req == REQ_SONG) { copySong(uri); ok = true; }
                else { saveCover(uri); ok = true; }
            } catch (Exception e) { ok = false; }
            final boolean fOk = ok;
            runOnUiThread(() -> {
                if (!fOk) Toast.makeText(this, "Faylni yuklab bo\u2018lmadi", Toast.LENGTH_LONG).show();
                updateStatus();
                SongWidget.refresh(this);
            });
        }).start();
    }

    private void copySong(Uri uri) throws Exception {
        File tmp = new File(getFilesDir(), "song.tmp");
        try (InputStream in = getContentResolver().openInputStream(uri);
             OutputStream out = new FileOutputStream(tmp)) {
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        }
        File dst = new File(getFilesDir(), "song");
        if (dst.exists()) dst.delete();
        if (!tmp.renameTo(dst)) throw new Exception("rename");
        sp.edit().putInt("pos", 0).apply();
        stopService(new Intent(this, MusicService.class)); // eski qo'shiq ijro bo'layotgan bo'lsa to'xtatadi
    }

    private void saveCover(Uri uri) throws Exception {
        final int S = 192;
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            BitmapFactory.decodeStream(in, null, o);
        }
        int sample = 1;
        while (Math.min(o.outWidth, o.outHeight) / (sample * 2) >= S) sample *= 2;
        o = new BitmapFactory.Options();
        o.inSampleSize = sample;
        Bitmap bmp;
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            bmp = BitmapFactory.decodeStream(in, null, o);
        }
        if (bmp == null) throw new Exception("decode");

        int rot = 0;
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            int ori = new ExifInterface(in).getAttributeInt(
                    ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
            if (ori == ExifInterface.ORIENTATION_ROTATE_90) rot = 90;
            else if (ori == ExifInterface.ORIENTATION_ROTATE_180) rot = 180;
            else if (ori == ExifInterface.ORIENTATION_ROTATE_270) rot = 270;
        } catch (Exception ignored) { }

        int side = Math.min(bmp.getWidth(), bmp.getHeight());
        int x = (bmp.getWidth() - side) / 2, y = (bmp.getHeight() - side) / 2;
        Matrix m = new Matrix();
        m.postScale(S / (float) side, S / (float) side);
        if (rot != 0) m.postRotate(rot, S / 2f, S / 2f);
        Bitmap sq = Bitmap.createBitmap(bmp, x, y, side, side, m, true);

        File dst = new File(getFilesDir(), "cover.jpg");
        try (OutputStream out = new FileOutputStream(dst)) {
            sq.compress(Bitmap.CompressFormat.JPEG, 90, out);
        }
    }
}
