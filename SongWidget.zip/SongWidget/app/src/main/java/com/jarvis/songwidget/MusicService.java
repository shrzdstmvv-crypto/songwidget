package com.jarvis.songwidget;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.IBinder;
import android.widget.Toast;

import java.io.File;

public class MusicService extends Service {
    private MediaPlayer mp;
    private AudioManager am;
    private AudioFocusRequest focusReq;
    private SharedPreferences sp;

    @Override
    public IBinder onBind(Intent i) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        sp = getSharedPreferences(SongWidget.PREFS, 0);
        startFg();
        if (mp != null && mp.isPlaying()) pause(); else play();
        return START_NOT_STICKY;
    }

    private void startFg() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel("song", "Музыка",
                NotificationManager.IMPORTANCE_LOW));
        Notification n = new Notification.Builder(this, "song")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle(sp.getString("title", getString(R.string.default_title)))
                .setContentText(sp.getString("artist", getString(R.string.default_artist)))
                .setOngoing(true)
                .build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        } else {
            startForeground(1, n);
        }
    }

    private void play() {
        File song = new File(getFilesDir(), "song");
        if (!song.exists()) {
            Toast.makeText(this, "Сначала выберите песню в приложении", Toast.LENGTH_LONG).show();
            stopAll();
            return;
        }
        am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        AudioAttributes attr = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build();
        focusReq = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(attr)
                .setOnAudioFocusChangeListener(f -> {
                    if (f == AudioManager.AUDIOFOCUS_LOSS
                            || f == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) {
                        if (mp != null && mp.isPlaying()) pause();
                    }
                }).build();
        am.requestAudioFocus(focusReq);

        try {
            mp = new MediaPlayer();
            mp.setAudioAttributes(attr);
            mp.setDataSource(song.getPath());
            mp.prepare();
            mp.setLooping(true);
            int pos = sp.getInt("pos", 0);
            if (pos > 0 && pos < mp.getDuration()) mp.seekTo(pos);
            mp.start();
        } catch (Exception e) {
            Toast.makeText(this, "Не удалось воспроизвести песню", Toast.LENGTH_LONG).show();
            stopAll();
            return;
        }
        sp.edit().putBoolean("playing", true).apply();
    }

    private void pause() {
        if (mp != null) {
            sp.edit().putInt("pos", mp.getCurrentPosition()).apply();
        }
        stopAll();
    }

    private void stopAll() {
        if (mp != null) { mp.release(); mp = null; }
        if (am != null && focusReq != null) am.abandonAudioFocusRequest(focusReq);
        sp.edit().putBoolean("playing", false).apply();
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    @Override
    public void onDestroy() {
        if (mp != null) { mp.release(); mp = null; }
        super.onDestroy();
    }
}
